package com.example.objectsrecognizer;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    //Variables
    String selectedImagePath;
    int PERMISSION_ALL = 1;
    String[] PERMISSIONS = {
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.INTERNET,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.ACCESS_FINE_LOCATION
    };

    //UI
    ImageView ivReturnedImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //final boolean isKitKat = Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT;

        //Ask for permissions
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !hasPermissions(this, PERMISSIONS)){
            ActivityCompat.requestPermissions(this, PERMISSIONS, PERMISSION_ALL);
        }

        ivReturnedImage = findViewById(R.id.ivReturnedImage);
    }

    //Method goes through permissions and ask for them if are not granted
    public static boolean hasPermissions(Context context, String... permissions) {
        if (context != null && permissions != null) {
            for (String permission : permissions) {
                if (ActivityCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED) {
                    return false;
                }
            }
        }
        return true;
    }

    //Method invoked when user press on Connect button
    //Get input server ip and port
    public void connectServer(View view) {
        //UI
        TextInputEditText etServerIp = findViewById(R.id.etServerIp);
        TextInputEditText etServerPort = findViewById(R.id.etServerPort);
        //Variables
        String serverIp = "", portNumber = "";
        boolean proceed = true;
        //Get server ip value
        if (etServerIp != null && etServerIp.getText() != null)
            serverIp = etServerIp.getText().toString();
        //Get server port value
        if (etServerPort != null && etServerPort.getText() != null)
            portNumber= etServerPort.getText().toString();
        //Check if server ip was entered, otherwise show error
        if (serverIp.equalsIgnoreCase("") && etServerIp != null) {
            etServerIp.setError(getResources().getString(R.string.server_ip_empty_error));
            proceed = false;
        }
        //Check if server port was entered, otherwise show error
        if (portNumber.equalsIgnoreCase("") && etServerPort != null) {
            etServerPort.setError(getResources().getString(R.string.server_port_empty_error));
            proceed = false;
        }
        //If server ip doesn't contains . then is invalid and show error
        if (!serverIp.contains(".") && etServerIp != null) {
            etServerIp.setError(getResources().getString(R.string.server_ip_not_valid));
            proceed = false;
        }
        if (selectedImagePath == null || selectedImagePath.equalsIgnoreCase("")) {
            Button btnSelectImage = findViewById(R.id.btnSelectImage);
            btnSelectImage.setError(getResources().getString(R.string.error_no_image_selected));
            proceed = false;
        }

        //If error was not found, than we can proceed to upload
        if (proceed) {
            // Image location URL
            //Log.e("INFO", "Path: " + selectedImagePath);

            // Image
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inSampleSize = 4;
            options.inPurgeable = true;
            Bitmap bitmap = BitmapFactory.decodeFile(selectedImagePath,options);
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG,40,byteArrayOutputStream);
            byte[] byteImage_photo = byteArrayOutputStream.toByteArray();
            String encodedImage =Base64.encodeToString(byteImage_photo,Base64.DEFAULT);

            //Log.e("base64", "-----" + encodedImage);


            new UploadImage(serverIp, portNumber, selectedImagePath, MainActivity.this, encodedImage).execute();
        }
    }

    private static class UploadImage extends AsyncTask<Void, Void, Void> {

        String serverIp, portNumber, imagePath, stringBytes;
        WeakReference<MainActivity> weakReference;
        ProgressDialog progressDialog;
        Bitmap bitmap;

        UploadImage(String serverIp, String portNumber, String imagePath, MainActivity mainActivity, String stringBytes) {
            this.serverIp = serverIp;
            this.portNumber = portNumber;
            this.imagePath = imagePath;
            weakReference = new WeakReference<>(mainActivity);
            this.stringBytes = stringBytes;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(weakReference.get());
            progressDialog.setMessage(weakReference.get().getResources().getString(R.string.uploading_image));
            progressDialog.setCancelable(false);
            progressDialog.show();
        }

        @Override
        protected Void doInBackground(Void... voids) {
            try {
                ArrayList<NameValuePair> nameValuePairs = new ArrayList<>();
                nameValuePairs.add(new BasicNameValuePair("base64", stringBytes));
                nameValuePairs.add(new BasicNameValuePair("ImageName", System.currentTimeMillis() + ".jpg"));
                try {
                    HttpClient httpclient = new DefaultHttpClient();
                    HttpPost httppost = new HttpPost("http://" + serverIp + ":" + portNumber + "/androidUpload");
                    httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
                    HttpResponse response = httpclient.execute(httppost);

                    if (response.getStatusLine().getStatusCode() == 200) {
                        HttpEntity entity = response.getEntity();
                        if (entity != null) {
                            InputStream inputStream = entity.getContent();
                            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                            int bufferSize = 1024;
                            byte[] buffer = new byte[bufferSize];
                            int len;
                            try {
                                while ((len = inputStream.read(buffer)) != -1) {
                                    byteArrayOutputStream.write(buffer, 0, len);
                                }
                                byteArrayOutputStream.close();
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                            byte[] b = byteArrayOutputStream.toByteArray();
                            bitmap = BitmapFactory.decodeByteArray(b, 0, b.length);
                        }
                    }
                } catch (Exception e) {
                    Log.e("ERROR", "Error in http connection " + e.toString());
                }

            } catch (Exception e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);

            if (progressDialog.isShowing())
                progressDialog.dismiss();

            if (bitmap != null) {
                weakReference.get().showReturnedImage(bitmap);
            }
        }
    }

    /**
     * Server edits image and returns it back to device
     * Method is used to show image that gets from server
     * @param bitmap bitmap image
     */
    public void showReturnedImage(final Bitmap bitmap) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                ivReturnedImage.setImageBitmap(bitmap);
                ivReturnedImage.setVisibility(View.VISIBLE);
            }
        });
    }

    //Select image when user press on button
    //After selecting the image, the Intent makes a call to a callback method onActivityResult
    public void selectImage(View view) {
        Intent intent = new Intent();
        intent.setType("*/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent, 0);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            selectedImagePath = getPath(getApplicationContext(), uri);

            String fileExtension = selectedImagePath.substring(selectedImagePath.lastIndexOf(".") + 1);

            if (fileExtension.equals("img") || fileExtension.equals("jpg")
                    || fileExtension.equals("jpeg") || fileExtension.equals("gif") || fileExtension.equals("png")) {
                Toast.makeText(getApplicationContext(), selectedImagePath, Toast.LENGTH_LONG).show();
            } else {
                //NOT IN REQUIRED FORMAT
                Toast.makeText(getApplicationContext(), "Selected file is not image or is not in allowed format! Please choose another one.", Toast.LENGTH_LONG).show();
            }
        }
    }

    /**
     * Get a file path from a Uri. This will get the the path for Storage Access
     * Framework Documents, as well as the _data field for the MediaStore and
     * other file-based ContentProviders.
     *
     * @param context The context.
     * @param uri The Uri to query.
     * @author paulburke
     */
    public static String getPath(final Context context, final Uri uri) {
        //final boolean isKitKat = Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT;

        // DocumentProvider
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT && DocumentsContract.isDocumentUri(context, uri)) {
            //This methods are only available for OS versions from Kitkat
            // ExternalStorageProvider
            if (isExternalStorageDocument(uri)) {
                final String docId = DocumentsContract.getDocumentId(uri);
                final String[] split = docId.split(":");
                final String type = split[0];

                if ("primary".equalsIgnoreCase(type)) {
                    return Environment.getExternalStorageDirectory() + "/" + split[1];
                }
            }
            // DownloadsProvider
            else if (isDownloadsDocument(uri)) {

                final String id = DocumentsContract.getDocumentId(uri);
                final Uri contentUri = ContentUris.withAppendedId(
                        Uri.parse("content://downloads/public_downloads"), Long.valueOf(id));

                return getDataColumn(context, contentUri, null, null);
            }
            // MediaProvider
            else if (isMediaDocument(uri)) {
                final String docId = DocumentsContract.getDocumentId(uri);
                final String[] split = docId.split(":");
                final String type = split[0];

                Uri contentUri = null;
                if ("image".equals(type)) {
                    contentUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                } else if ("video".equals(type)) {
                    contentUri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                } else if ("audio".equals(type)) {
                    contentUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
                }

                final String selection = "_id=?";
                final String[] selectionArgs = new String[] {
                        split[1]
                };

                return getDataColumn(context, contentUri, selection, selectionArgs);
            }
        }
        // MediaStore (and general)
        else if ("content".equalsIgnoreCase(uri.getScheme())) {
            return getDataColumn(context, uri, null, null);
        }
        // File
        else if ("file".equalsIgnoreCase(uri.getScheme())) {
            return uri.getPath();
        }

        return null;
    }

    /**
     * Get the value of the data column for this Uri. This is useful for
     * MediaStore Uris, and other file-based ContentProviders.
     *
     * @param context The context.
     * @param uri The Uri to query.
     * @param selection (Optional) Filter used in the query.
     * @param selectionArgs (Optional) Selection arguments used in the query.
     * @return The value of the _data column, which is typically a file path.
     */
    public static String getDataColumn(Context context, Uri uri, String selection, String[] selectionArgs) {
        Cursor cursor = null;
        final String column = "_data";
        final String[] projection = {
                column
        };

        try {
            cursor = context.getContentResolver().query(uri, projection, selection, selectionArgs,
                    null);
            if (cursor != null && cursor.moveToFirst()) {
                final int column_index = cursor.getColumnIndexOrThrow(column);
                return cursor.getString(column_index);
            }
        } finally {
            if (cursor != null)
                cursor.close();
        }

        return null;
    }


    /**
     * @param uri The Uri to check.
     * @return Whether the Uri authority is ExternalStorageProvider.
     */
    public static boolean isExternalStorageDocument(Uri uri) {
        return "com.android.externalstorage.documents".equals(uri.getAuthority());
    }

    /**
     * @param uri The Uri to check.
     * @return Whether the Uri authority is DownloadsProvider.
     */
    public static boolean isDownloadsDocument(Uri uri) {
        return "com.android.providers.downloads.documents".equals(uri.getAuthority());
    }

    /**
     * @param uri The Uri to check.
     * @return Whether the Uri authority is MediaProvider.
     */
    public static boolean isMediaDocument(Uri uri) {
        return "com.android.providers.media.documents".equals(uri.getAuthority());
    }
}
